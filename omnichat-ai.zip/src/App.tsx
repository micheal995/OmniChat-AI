/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { db } from './lib/firebase';
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, getDocs, limit } from 'firebase/firestore';
import { Conversation, ConversationStatus } from './types/chat';
import { ConversationList } from './components/ConversationList';
import { ChatWindow } from './components/ChatWindow';
import { handleFirestoreError, OperationType } from './lib/utils';
import { LayoutGrid, Users, Activity, Plus, Sparkles, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<ConversationStatus | 'all'>('all');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'conversations'), orderBy('updatedAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const convs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Conversation));
      setConversations(convs);
      setIsLoading(false);
      
      // Seed if empty
      if (convs.length === 0 && !isLoading) {
        seedInitialData();
      }
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'conversations');
    });

    return () => unsubscribe();
  }, [isLoading]);

  const seedInitialData = async () => {
    const names = ["Sarah Johnson", "Michael Chen", "Emma Wilson", "David Smith", "Project Zeta Admin"];
    const initialMsgs = [
      "Hello, I need help with my subscription.",
      "Is the API down? I'm getting 504 errors.",
      "How do I upgrade to the enterprise plan?",
      "Can we schedule a demo for my team?",
      "URGENT: Security vulnerability report."
    ];

    for (let i = 0; i < names.length; i++) {
      const convRef = await addDoc(collection(db, 'conversations'), {
        customerName: names[i],
        status: i % 2 === 0 ? 'active' : 'pending',
        lastMessage: initialMsgs[i],
        updatedAt: serverTimestamp(),
        createdAt: serverTimestamp(),
        aiEnabled: i % 3 === 0
      });

      await addDoc(collection(db, 'conversations', convRef.id, 'messages'), {
        text: initialMsgs[i],
        sender: 'customer',
        createdAt: serverTimestamp()
      });
    }
  };

  const createNewChat = async () => {
    const names = ["Alice Rogers", "Bob Miller", "Cindy Lauper", "Dan Brown"];
    const name = names[Math.floor(Math.random() * names.length)];
    const convRef = await addDoc(collection(db, 'conversations'), {
      customerName: name,
      status: 'pending',
      lastMessage: 'Awaiting first response...',
      updatedAt: serverTimestamp(),
      createdAt: serverTimestamp(),
      aiEnabled: true
    });
    setSelectedId(convRef.id);
  };

  const selectedConv = conversations.find(c => c.id === selectedId);

  return (
    <div className="flex h-screen bg-zinc-950 font-sans selection:bg-orange-500/30 selection:text-orange-200 overflow-hidden">
      {/* Mini Sidebar */}
      <div className="w-16 bg-zinc-950 border-r border-zinc-900 flex flex-col items-center py-6 gap-8 z-20">
        <div className="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/20">
          <Sparkles className="text-white" size={24} />
        </div>
        <div className="flex flex-col gap-6">
          <nav className="flex flex-col gap-4">
             <button className="p-3 text-zinc-100 bg-zinc-800 rounded-xl transition-all"><LayoutGrid size={20} /></button>
             <button className="p-3 text-zinc-500 hover:text-zinc-200 transition-all"><Users size={20} /></button>
             <button className="p-3 text-zinc-500 hover:text-zinc-200 transition-all"><Activity size={20} /></button>
          </nav>
        </div>
        <div className="mt-auto">
          <button 
            onClick={createNewChat}
            className="w-10 h-10 bg-zinc-800 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-700 rounded-xl flex items-center justify-center transition-all border border-zinc-700/50"
          >
            <Plus size={20} />
          </button>
        </div>
      </div>

      <ConversationList
        conversations={conversations}
        selectedId={selectedId}
        onSelect={setSelectedId}
        filterStatus={filterStatus}
        setFilterStatus={setFilterStatus}
      />

      <main className="flex-1 overflow-hidden h-full flex flex-col relative">
        <AnimatePresence mode="wait">
          {selectedConv ? (
            <motion.div 
              key={selectedConv.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="h-full w-full"
            >
              <ChatWindow conversation={selectedConv} />
            </motion.div>
          ) : (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex-1 flex flex-col items-center justify-center p-8 text-center"
            >
              <div className="max-w-md">
                <div className="mb-8 relative inline-block">
                  <div className="absolute inset-0 bg-orange-500 blur-3xl opacity-10 animate-pulse" />
                  <MessageSquare size={80} className="text-zinc-800 relative z-10 mx-auto" />
                </div>
                <h1 className="text-4xl font-bold text-zinc-100 tracking-tight mb-4 italic serif">
                  OmniChat <span className="text-orange-500">Dashboard</span>
                </h1>
                <p className="text-zinc-500 text-lg mb-8 leading-relaxed">
                  Welcome to your command center. Handle multiple customer engagements simultaneously with AI-powered assistance.
                </p>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-6 bg-zinc-900 border border-zinc-800 rounded-2xl text-left">
                    <h4 className="text-zinc-300 font-bold text-xs uppercase tracking-[0.2em] mb-2 font-mono">Active Streams</h4>
                    <span className="text-3xl font-light text-zinc-100">{conversations.filter(c => c.status === 'active').length}</span>
                  </div>
                  <div className="p-6 bg-zinc-900 border border-zinc-800 rounded-2xl text-left">
                     <h4 className="text-zinc-300 font-bold text-xs uppercase tracking-[0.2em] mb-2 font-mono">Pending Response</h4>
                     <span className="text-3xl font-light text-orange-500">{conversations.filter(c => c.status === 'pending').length}</span>
                  </div>
                </div>

                <div className="mt-12 flex flex-col gap-4">
                  <div className="flex items-center gap-2 text-zinc-600 self-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                    <span className="text-[10px] font-bold uppercase tracking-widest leading-none">System Operational</span>
                  </div>
                  <p className="text-[10px] text-zinc-700 uppercase tracking-[0.3em]">
                    Real-time Synchronization Enabled | Firebase Vertex
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar {
          width: 5px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #27272a;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #3f3f46;
        }
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
      ` }} />
    </div>
  );
}
