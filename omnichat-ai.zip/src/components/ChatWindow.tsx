import React, { useState, useEffect, useRef } from 'react';
import { Send, Bot, User, ShieldCheck, Sparkles, AlertCircle } from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { collection, addDoc, query, orderBy, onSnapshot, serverTimestamp, doc, updateDoc, Timestamp } from 'firebase/firestore';
import { Conversation, Message, Sender, ConversationStatus } from '../types/chat';
import { cn, handleFirestoreError, OperationType } from '../lib/utils';
import { ai, SYSTEM_INSTRUCTION } from '../lib/gemini';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';

interface ChatWindowProps {
  conversation: Conversation;
}

export const ChatWindow: React.FC<ChatWindowProps> = ({ conversation }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const messagesRef = collection(db, 'conversations', conversation.id, 'messages');
    const q = query(messagesRef, orderBy('createdAt', 'asc'));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Message));
      setMessages(msgs);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, `conversations/${conversation.id}/messages`);
    });

    return () => unsubscribe();
  }, [conversation.id]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  // Handle AI Auto-reply
  useEffect(() => {
    const lastMsg = messages[messages.length - 1];
    if (conversation.aiEnabled && lastMsg && lastMsg.sender === 'customer') {
      triggerAIResponse(lastMsg.text);
    }
  }, [messages.length, conversation.aiEnabled]);

  const triggerAIResponse = async (text: string) => {
    if (!ai) return;
    setIsTyping(true);
    try {
      // Build context
      const history = messages.slice(-5).map(m => `${m.sender}: ${m.text}`).join('\n');
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Context:\n${history}\n\nCustomer: ${text}`,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION
        }
      });

      const aiText = response.text || "I'm sorry, I encountered an error processing that.";
      await sendMessage(aiText, 'ai');
    } catch (error) {
      console.error('AI Error:', error);
    } finally {
      setIsTyping(false);
    }
  };

  const sendMessage = async (text: string, sender: 'agent' | 'ai') => {
    if (!text.trim()) return;
    const path = `conversations/${conversation.id}/messages`;
    try {
      // Add message
      await addDoc(collection(db, 'conversations', conversation.id, 'messages'), {
        text: text.trim(),
        sender,
        createdAt: serverTimestamp()
      });

      // Update conversation metadata
      await updateDoc(doc(db, 'conversations', conversation.id), {
        lastMessage: text.trim(),
        updatedAt: serverTimestamp(),
        status: 'active' as ConversationStatus
      });
      
      if (sender === 'agent') setInputText('');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  };

  const toggleAI = async () => {
    try {
      await updateDoc(doc(db, 'conversations', conversation.id), {
        aiEnabled: !conversation.aiEnabled,
        updatedAt: serverTimestamp()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `conversations/${conversation.id}`);
    }
  };

  const resolveChat = async () => {
    try {
      await updateDoc(doc(db, 'conversations', conversation.id), {
        status: 'resolved',
        updatedAt: serverTimestamp()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `conversations/${conversation.id}`);
    }
  };

  return (
    <div className="flex flex-col h-full bg-zinc-950 flex-1 relative overflow-hidden">
      {/* Header */}
      <div className="h-16 border-b border-zinc-800 flex items-center justify-between px-6 bg-zinc-900/50 backdrop-blur-md z-10">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-zinc-800 rounded-lg">
            <User className="text-zinc-400" size={20} />
          </div>
          <div>
            <h3 className="text-zinc-100 font-semibold text-sm">{conversation.customerName}</h3>
            <span className="text-[10px] text-zinc-500 uppercase tracking-tighter">Query ID: {conversation.id.slice(0,8)}</span>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={toggleAI}
            className={cn(
              "flex items-center gap-2 px-3 py-1.5 rounded-md border transition-all text-xs font-bold",
              conversation.aiEnabled 
                ? "bg-orange-500/10 border-orange-500/50 text-orange-500" 
                : "bg-zinc-800 border-transparent text-zinc-400 hover:text-zinc-200"
            )}
          >
            <Sparkles size={14} className={conversation.aiEnabled ? "animate-pulse" : ""} />
            AI PILOT: {conversation.aiEnabled ? "ACTIVE" : "OFF"}
          </button>
          <button 
            onClick={resolveChat}
            className="text-xs bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-3 py-1.5 rounded-md border border-zinc-700/50 transition-all"
          >
            RESOLVE
          </button>
        </div>
      </div>

      {/* Messages */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 flex flex-col gap-6 custom-scrollbar"
      >
        <AnimatePresence initial={false}>
          {messages.map((m) => (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "flex flex-col max-w-[80%]",
                m.sender === 'customer' ? "self-start" : "self-end items-end"
              )}
            >
              <div className={cn(
                "group relative px-4 py-3 rounded-2xl text-sm leading-relaxed",
                m.sender === 'customer' 
                  ? "bg-zinc-800 text-zinc-100 rounded-bl-sm" 
                  : m.sender === 'ai'
                    ? "bg-orange-600/90 text-white rounded-br-sm shadow-lg shadow-orange-500/20"
                    : "bg-zinc-100 text-zinc-900 rounded-br-sm"
              )}>
                {m.text}
                <div className={cn(
                  "absolute -bottom-5 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap",
                  m.sender === 'customer' ? "left-0" : "right-0"
                )}>
                  <span className="text-[9px] text-zinc-600 font-mono">
                    {m.createdAt ? format(m.createdAt.toDate(), 'HH:mm') : '...'}
                  </span>
                  {m.sender === 'ai' && <Bot size={10} className="text-orange-500/50" />}
                </div>
              </div>
              <span className="text-[10px] text-zinc-600 mt-1 uppercase tracking-widest font-bold">
                {m.sender}
              </span>
            </motion.div>
          ))}
        </AnimatePresence>
        
        {isTyping && (
          <div className="self-end mr-4">
            <div className="flex gap-1.5 p-2 bg-orange-500/10 rounded-full border border-orange-500/20">
              <div className="w-1.5 h-1.5 bg-orange-500 rounded-full animate-bounce [animation-delay:-0.3s]" />
              <div className="w-1.5 h-1.5 bg-orange-500 rounded-full animate-bounce [animation-delay:-0.15s]" />
              <div className="w-1.5 h-1.5 bg-orange-500 rounded-full animate-bounce" />
            </div>
          </div>
        )}
      </div>

      {/* Input */}
      <div className="p-4 bg-zinc-900/80 border-t border-zinc-800 backdrop-blur-md">
        <form 
          onSubmit={(e) => { e.preventDefault(); sendMessage(inputText, 'agent'); }}
          className="flex gap-4 items-center max-w-5xl mx-auto w-full"
        >
          <div className="flex-1 relative">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={conversation.status === 'resolved' ? "Conversation resolved. Ask to reopen..." : "Type your message as agent..."}
              className="w-full bg-zinc-800 text-zinc-100 px-4 py-3 rounded-xl border border-zinc-700 focus:outline-none focus:border-zinc-500 transition-all pr-12 text-sm"
            />
            <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
              <ShieldCheck size={16} className="text-zinc-600" />
            </div>
          </div>
          <button 
            disabled={!inputText.trim()}
            className="p-3 bg-zinc-100 disabled:opacity-50 hover:bg-white text-zinc-950 rounded-xl transition-all active:scale-95 shadow-lg shadow-white/5"
          >
            <Send size={18} />
          </button>
        </form>
        <div className="mt-2 text-center">
           <span className="text-[9px] text-zinc-600 uppercase tracking-[0.2em] font-medium">
             OmniChat Protocol v3.1 | End-to-End Encrypted | AI Grounded
           </span>
        </div>
      </div>
    </div>
  );
};
