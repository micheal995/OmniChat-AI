import React from 'react';
import { Search, Filter, MessageSquare, Clock, CheckCircle2, User } from 'lucide-react';
import { Conversation, ConversationStatus } from '../types/chat';
import { cn } from '../lib/utils';
import { formatDistanceToNow } from 'date-fns';

interface ConversationListProps {
  conversations: Conversation[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  filterStatus: ConversationStatus | 'all';
  setFilterStatus: (status: ConversationStatus | 'all') => void;
}

export const ConversationList: React.FC<ConversationListProps> = ({
  conversations,
  selectedId,
  onSelect,
  filterStatus,
  setFilterStatus,
}) => {
  const filtered = conversations.filter(c => filterStatus === 'all' || c.status === filterStatus);

  return (
    <div className="flex flex-col h-full bg-zinc-900 border-r border-zinc-800 w-80">
      <div className="p-4 border-b border-zinc-800">
        <h2 className="text-zinc-100 font-semibold text-lg flex items-center gap-2">
          <MessageSquare size={18} className="text-orange-500" />
          Conversations
        </h2>
        <div className="mt-4 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" size={16} />
          <input
            type="text"
            placeholder="Search queries..."
            className="w-full bg-zinc-800 text-zinc-200 text-sm pl-10 pr-4 py-2 rounded-md outline-none focus:ring-1 focus:ring-orange-500/50 transition-all border border-transparent focus:border-orange-500/30"
          />
        </div>
        <div className="flex gap-2 mt-4 overflow-x-auto pb-1 scrollbar-none">
          {(['all', 'active', 'pending', 'resolved'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setFilterStatus(s)}
              className={cn(
                "px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-all border",
                filterStatus === s 
                  ? "bg-orange-500/10 text-orange-500 border-orange-500/50" 
                  : "bg-zinc-800 text-zinc-400 border-transparent hover:bg-zinc-700"
              )}
            >
              {s.charAt(0).toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar">
        {filtered.map((conv) => (
          <button
            key={conv.id}
            onClick={() => onSelect(conv.id)}
            className={cn(
              "w-full p-4 flex flex-col gap-1 border-b border-zinc-800 transition-all text-left group relative",
              selectedId === conv.id ? "bg-zinc-800/50" : "hover:bg-zinc-800/30"
            )}
          >
            {selectedId === conv.id && (
              <div className="absolute left-0 top-0 bottom-0 w-1 bg-orange-500" />
            )}
            <div className="flex justify-between items-start">
              <span className="text-zinc-200 font-medium text-sm flex items-center gap-2">
                <User size={14} className="text-zinc-500" />
                {conv.customerName}
              </span>
              <span className="text-[10px] text-zinc-500 whitespace-nowrap flex items-center gap-1">
                <Clock size={10} />
                {formatDistanceToNow(conv.updatedAt.toDate(), { addSuffix: true })}
              </span>
            </div>
            <p className="text-xs text-zinc-400 line-clamp-1 h-4">
              {conv.lastMessage || "No messages yet"}
            </p>
            <div className="flex items-center gap-2 mt-1">
               <div className={cn(
                  "w-1.5 h-1.5 rounded-full",
                  conv.status === 'active' && "bg-green-500 animate-pulse",
                  conv.status === 'pending' && "bg-orange-500",
                  conv.status === 'resolved' && "bg-zinc-600"
                )} />
                <span className="text-[10px] uppercase tracking-wider text-zinc-500 font-bold">
                  {conv.status}
                </span>
                {conv.aiEnabled && (
                  <span className="text-[9px] bg-orange-500/10 text-orange-500 border border-orange-500/30 px-1.5 rounded uppercase font-bold">
                    AI Active
                  </span>
                )}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
