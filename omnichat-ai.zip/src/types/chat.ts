import { Timestamp } from 'firebase/firestore';

export type ConversationStatus = 'active' | 'resolved' | 'pending';
export type Sender = 'customer' | 'ai' | 'agent';

export interface Conversation {
  id: string;
  customerName: string;
  status: ConversationStatus;
  lastMessage?: string;
  updatedAt: Timestamp;
  createdAt: Timestamp;
  aiEnabled: boolean;
}

export interface Message {
  id: string;
  text: string;
  sender: Sender;
  createdAt: Timestamp;
}
